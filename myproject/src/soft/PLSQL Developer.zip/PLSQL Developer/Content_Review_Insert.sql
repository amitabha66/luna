select * from cms_wof_workflow wof where wof.workflow_name like '%Content%'

INSERT INTO cms_wof_workflow
VALUES
  ((SELECT MAX(wof_pk) + 1 FROM cms_wof_workflow),
   'Content Review',
   'Content Review',
   'CR',
   'D',
   NULL,
   '-99',
   SYSDATE,
   NULL,
   NULL);
   
  
  select * from cms_wft_workflow_tasks where task_name like '%Content%'
   
   INSERT INTO cms_wft_workflow_tasks
   VALUES
  ((SELECT MAX(wft_pk) + 1 FROM cms_wft_workflow_tasks),
   (SELECT wof_pk
     FROM cms_wof_workflow
     WHERE workflow_name = 'Content Review'),
   'Content_Edit Review',
   'Content_Edit Review',
   'USG',
   NULL,
   '-99',
   SYSDATE,
   NULL,
   NULL,
   NULL,
   NULL,
   NULL,
   NULL);
   
   INSERT INTO cms_wft_workflow_tasks
VALUES
  ((SELECT MAX(wft_pk) + 1 FROM cms_wft_workflow_tasks),
   (SELECT wof_pk
      FROM cms_wof_workflow
     WHERE workflow_name = 'Content Review'),
   'Reconcile Content_Edit Comments',
   'Reconcile Content_Edit Comments',
   'USG',
   NULL,
   '-99',
   SYSDATE,
   NULL,
   NULL,
   NULL,
   NULL,
   NULL,
   NULL);