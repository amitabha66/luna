select a.wft_pk, a.task_name, a.performer_ind from cms_wft_workflow_tasks a, cms_wof_workflow b where
a.wof_pk = b.wof_pk and nvl(a.display_ind,'x') <> 'N' 

select * from cms_wft_workflow_tasks where wof_pk = 2270014

select * from cms_wof_workflow where workflow_name like '%Verify%'


SELECT DISTINCT COM_MISC_SQL.CODEDTOMEANING('V_ROLE_TYPE',RLE.ROLE_TYPE), RLE.ROLE_TYPE FROM CMS_WFT_WORKFLOW_TASKS WFT, 
CMS_WOF_WORKFLOW WOF, SEC_RTM_ROLE_TASK_MAP  RTM,  SEC_RLE_ROLE RLE WHERE WOF.WOF_PK = 2270032 AND WOF.WOF_PK = WFT.WOF_PK AND
WFT.TASK_NAME = 'Style Edit Review Art' AND WFT.WFT_PK = RTM.WFT_PK AND RLE.ROLE_PK = RTM.ROLE_PK

select cjb.batch_doc_ref_id from cms_jor_job_request jor, cms_job_batches job, ccd_cjb_content_job_batch cjb where 
cjb.batch_pk = job.batch_pk and job.jor_pk = jor.jor_pk 

select * from cms_jor_job_request 

select * from cms_job_batches

select * from ccd_cjb_content_job_batch

select * from cms_tan_task_allocation 

select * from slm_pgm_program

select pgm.short_name from slm_pgm_program pgm where pgm.PROGRAM_NAME = 'Acuity%'

update ccd_cjb_content_job_batch t set t.batch_doc_ref_id = ? where
t.batch_pk = (select job.batch_pk from  cms_job_batches job, cms_jor_job_request jor 
where t.batch_pk = job.batch_pk and job.jor_pk = jor.jor_pk and jor.jor_pk = ?)

select * from ccd_cjb_content_job_batch where batch_pk = 7335920

select * from cms_job_batches where jor_pk = 7335919

select * from cms_jor_job_request

select * from slm_pgu_program_group_user

select * from slm_pgm_program

select * from slm_dct_dctm_docbase

select * from sec_usr_user where reference_user_id like 'arindam%'

select pgm.program_pk pkey, pgm.program_name programName, dct.dctm_docbase_pk docbasePkey, dct.docbase_name docbaseName from 
slm_pgu_program_group_user pgu, slm_pgm_program pgm, slm_dct_dctm_docbase dct, sec_usr_user usr
WHERE pgu.program_pk = pgm.program_pk AND pgm.dctm_docbase_pk = dct.dctm_docbase_pk AND pgu.user_pk = usr.user_pk
AND usr.reference_user_id = 'amir_khan' AND dct.status = 'A'

Select usr.reference_user_id from cms_ven_vendor ven, sec_usr_user usr where ven.vendor_pk = 7152131 and ven.user_pk = usr.user_pk
select * from cms_ven_vendor where name like 'Acuity%'
select * from sec_usr_user where reference_user_id like 'amir%'

select * from cms_tan_task_allocation

select * from cms_wft_workflow_tasks where task_name like 'Develop%'

select * from cms_wof_workflow where wof_pk = 2270014

select * from sec_usg_user_group
select * from ccd_itm_item itm where itm.itm_business_id = 'SR0003B4BA'

select * from cms_jor_job_request
update cms_jor_job_request set status = 'COM' where job_request_name in('Lipika_JobReq12','Lipika_JobReq13')

select * from cms_hlj_high_lvl_job_req